"""Module entry point for ``python -m fabtwin``."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
